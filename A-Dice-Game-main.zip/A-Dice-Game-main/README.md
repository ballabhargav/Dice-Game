# A-Dice-Game
we have built a dice game ,a unique game from our  thaughts which we have done using Html,CSS and java script
